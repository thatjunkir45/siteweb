
# Pengonsol Club

This repository contains the assets and files for the Pengonsol Club website.

## Structure

- **assets-global.website-files.com**: Global website assets.
- **cdn.jsdelivr.net**: External CDN resources.
- **necolas.github.io**: Additional external assets.
- **p.typekit.net**: Typekit font files.
- **pengonsol.club**: Main website files.
- **use.typekit.net**: Typekit usage resources.
- **www.googletagmanager.com**: Google Tag Manager resources.

## How to Use

1. Clone this repository to your local machine:
   ```bash
   git clone <repository-url>
   ```
2. Use the files as needed for your project.

## License

Specify the license under which this repository is shared (if applicable).
